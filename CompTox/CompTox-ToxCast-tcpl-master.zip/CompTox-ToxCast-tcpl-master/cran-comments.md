Reduced size of concepts to align with CRAN requirements
New release includes additional functionality for package, and moves data.table to suggests.

## Test environments

* local Windows 10 install, R 3.6.1

## R CMD check results

0 ERRORs | 0 WARNINGs | 0 NOTES.

## Downstream dependencies

* There are 0 Downstream dependencies for this package.
